package com.adplanner.app.data

import java.time.LocalDate
import java.time.LocalDateTime

val Categories = listOf("Fitness", "Routine", "English", "Tech")

fun fmtMin(m: Int): String {
    val h = m / 60
    val mm = m % 60
    val ap = if (h < 12) "AM" else "PM"
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "%d:%02d %s".format(h12, mm, ap)
}

data class DayStat(val done: Int, val counted: Int, val scheduled: Int) {
    val ratio: Float get() = if (counted == 0) 0f else done.toFloat() / counted
}

object Logic {
    fun applies(t: TaskEntity, d: LocalDate): Boolean = (t.daysMask shr (d.dayOfWeek.value - 1)) and 1 == 1

    fun doneSet(c: List<CompletionEntity>): Set<String> =
        c.filter { it.done }.map { "${it.taskId}|${it.date}" }.toHashSet()

    /** Future tasks are never counted as missed: a task counts only if done, on a past day,
     *  or today and already ended. */
    fun day(tasks: List<TaskEntity>, done: Set<String>, d: LocalDate, now: LocalDateTime): DayStat {
        val today = now.toLocalDate()
        val nowMin = now.hour * 60 + now.minute
        var sc = 0; var ct = 0; var dn = 0
        for (t in tasks) {
            if (!applies(t, d)) continue
            sc++
            val isDone = "${t.id}|$d" in done
            if (isDone) dn++
            if (isDone || d.isBefore(today) || (d == today && t.endMin <= nowMin)) ct++
        }
        return DayStat(dn, ct, sc)
    }

    /** A day is "good" when at least 70% of its counted tasks are done. */
    fun streak(tasks: List<TaskEntity>, done: Set<String>, now: LocalDateTime): Int {
        var d = now.toLocalDate()
        var s = 0
        val t = day(tasks, done, d, now)
        if (t.scheduled > 0 && t.counted > 0 && t.ratio >= 0.7f) s++
        d = d.minusDays(1)
        for (i in 0 until 365) {
            val st = day(tasks, done, d, now)
            if (st.scheduled > 0) {
                if (st.ratio >= 0.7f) s++ else return s
            }
            d = d.minusDays(1)
        }
        return s
    }

    fun catRate(tasks: List<TaskEntity>, done: Set<String>, now: LocalDateTime, cat: String): Float? {
        var d = 0; var c = 0
        val list = tasks.filter { it.category == cat }
        for (i in 0..29) {
            val st = day(list, done, now.toLocalDate().minusDays(i.toLong()), now)
            d += st.done; c += st.counted
        }
        return if (c == 0) null else d.toFloat() / c
    }

    fun seed(): List<TaskEntity> = listOf(
        TaskEntity(title = "Wake up & freshen up", startMin = 300, endMin = 330, category = "Routine"),
        TaskEntity(title = "Workout", startMin = 330, endMin = 390, category = "Fitness"),
        TaskEntity(title = "Bath & breakfast", startMin = 390, endMin = 450, category = "Routine"),
        TaskEntity(title = "Python practice", startMin = 480, endMin = 600, category = "Tech"),
        TaskEntity(title = "Prompt engineering", startMin = 600, endMin = 660, category = "Tech"),
        TaskEntity(title = "English reading", startMin = 660, endMin = 720, category = "English"),
        TaskEntity(title = "Lunch & rest", startMin = 720, endMin = 780, category = "Routine"),
        TaskEntity(title = "Project building", startMin = 780, endMin = 900, category = "Tech"),
        TaskEntity(title = "English speaking", startMin = 900, endMin = 960, category = "English"),
        TaskEntity(title = "Evening walk / exercise", startMin = 1020, endMin = 1080, category = "Fitness"),
        TaskEntity(title = "Dinner", startMin = 1140, endMin = 1170, category = "Routine"),
        TaskEntity(title = "Typing practice", startMin = 1170, endMin = 1200, category = "Tech"),
        TaskEntity(title = "Review & plan tomorrow", startMin = 1200, endMin = 1260, category = "Routine")
    )
}
