package com.adplanner.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object Backup {
    suspend fun export(c: Context): String {
        val dao = AppDb.get(c).dao()
        val root = JSONObject().put("app", "adplanner2").put("version", 1)
        root.put("tasks", JSONArray().apply {
            dao.tasksNow().forEach {
                put(JSONObject().put("id", it.id).put("title", it.title).put("startMin", it.startMin)
                    .put("endMin", it.endMin).put("category", it.category)
                    .put("daysMask", it.daysMask).put("remind", it.remind))
            }
        })
        root.put("completions", JSONArray().apply {
            dao.completionsNow().forEach {
                put(JSONObject().put("taskId", it.taskId).put("date", it.date).put("done", it.done))
            }
        })
        root.put("notes", JSONArray().apply {
            dao.notesNow().forEach { put(JSONObject().put("text", it.text).put("createdAt", it.createdAt)) }
        })
        root.put("focus", JSONArray().apply {
            dao.focusNow().forEach { put(JSONObject().put("date", it.date).put("minutes", it.minutes)) }
        })
        return root.toString(2)
    }

    private val timeRe = Regex("""(\d{1,2}):(\d{2})\s*([AaPp][Mm])?""")

    fun parseMin(v: Any?): Int? {
        if (v is Number) return v.toInt()
        val m = timeRe.find(v?.toString()?.trim() ?: return null) ?: return null
        var h = m.groupValues[1].toInt()
        val mi = m.groupValues[2].toInt()
        val ap = m.groupValues[3].lowercase()
        if (ap == "pm" && h < 12) h += 12
        if (ap == "am" && h == 12) h = 0
        return h * 60 + mi
    }

    private fun mapCategory(s: String): String {
        val l = s.lowercase()
        return Categories.firstOrNull { l.contains(it.lowercase()) }
            ?: if (l.contains("gym") || l.contains("workout") || l.contains("health")) "Fitness"
            else if (l.contains("code") || l.contains("python") || l.contains("skill")) "Tech" else "Routine"
    }

    /** Replaces timetable + completions. Reads the native backup format, and does a best-effort
     *  read of the old web tracker's JSON (tasks array + history map). */
    suspend fun import(c: Context, text: String): String {
        val dao = AppDb.get(c).dao()
        val root = JSONObject(text)
        val arr = root.optJSONArray("tasks") ?: return "No \"tasks\" found in this file."
        val native = root.optString("app") == "adplanner2"
        val idMap = HashMap<String, Long>()
        dao.clearCompletions(); dao.clearTasks()
        var count = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val key = if (o.has("id")) o.get("id").toString() else i.toString()
            val title = listOf("title", "name", "task", "label").firstNotNullOfOrNull {
                o.optString(it, "").takeIf { s -> s.isNotBlank() }
            } ?: continue
            val start = (if (native) parseMin(o.opt("startMin")) else null)
                ?: listOf("startMin", "start", "startTime", "time").firstNotNullOfOrNull { parseMin(o.opt(it)) }
                ?: continue
            val end = (listOf("endMin", "end", "endTime").firstNotNullOfOrNull { parseMin(o.opt(it)) }
                ?: (start + 60)).let { if (it <= start) start + 30 else it }
            val cat = o.optString("category", o.optString("cat", o.optString("type", "")))
            val newId = dao.insertTask(
                TaskEntity(
                    title = title, startMin = start, endMin = end,
                    category = if (native) cat.ifBlank { "Routine" } else mapCategory(cat + " " + title),
                    daysMask = o.optInt("daysMask", 127), remind = o.optBoolean("remind", true)
                )
            )
            idMap[key] = newId; count++
        }
        var comps = 0
        val list = ArrayList<CompletionEntity>()
        root.optJSONArray("completions")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val id = idMap[o.opt("taskId")?.toString() ?: ""] ?: continue
                list.add(CompletionEntity(id, o.optString("date"), o.optBoolean("done", true)))
            }
        }
        val hist = root.optJSONObject("history") ?: root.optJSONObject("log") ?: root.optJSONObject("days")
        hist?.keys()?.forEach { date ->
            if (runCatching { LocalDate.parse(date) }.isFailure) return@forEach
            val v = hist.opt(date)
            if (v is JSONObject) {
                v.keys().forEach { k ->
                    val id = idMap[k]
                    if (id != null && v.optBoolean(k, false)) list.add(CompletionEntity(id, date, true))
                }
            }
            if (v is JSONArray) {
                for (j in 0 until v.length()) {
                    val id = idMap[v.opt(j).toString()]
                    if (id != null) list.add(CompletionEntity(id, date, true))
                }
            }
        }
        if (list.isNotEmpty()) { dao.setCompletions(list); comps = list.size }
        root.optJSONArray("notes")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                dao.insertNote(NoteEntity(text = o.optString("text"), createdAt = o.optLong("createdAt", System.currentTimeMillis())))
            }
        }
        root.optJSONArray("focus")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                dao.insertFocus(FocusEntity(date = o.optString("date"), minutes = o.optInt("minutes")))
            }
        }
        return "Imported $count tasks and $comps completions."
    }
}
