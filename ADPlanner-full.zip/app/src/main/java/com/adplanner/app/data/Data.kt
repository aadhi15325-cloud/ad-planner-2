package com.adplanner.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val startMin: Int,
    val endMin: Int,
    val category: String,
    val daysMask: Int = 127, // bit0 = Monday ... bit6 = Sunday
    val remind: Boolean = true
)

@Entity(tableName = "completions", primaryKeys = ["taskId", "date"])
data class CompletionEntity(val taskId: Long, val date: String, val done: Boolean)

@Entity(tableName = "notes")
data class NoteEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String, val createdAt: Long)

@Entity(tableName = "focus")
data class FocusEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val date: String, val minutes: Int)

@Dao
interface PlannerDao {
    @Query("SELECT * FROM tasks ORDER BY startMin") fun tasks(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks") suspend fun tasksNow(): List<TaskEntity>
    @Query("SELECT * FROM tasks WHERE id = :id") suspend fun task(id: Long): TaskEntity?
    @Insert suspend fun insertTask(t: TaskEntity): Long
    @Update suspend fun updateTask(t: TaskEntity)
    @Query("DELETE FROM tasks WHERE id = :id") suspend fun deleteTask(id: Long)
    @Query("DELETE FROM completions WHERE taskId = :id") suspend fun deleteCompletionsFor(id: Long)
    @Query("DELETE FROM tasks") suspend fun clearTasks()
    @Query("DELETE FROM completions") suspend fun clearCompletions()

    @Query("SELECT * FROM completions") fun completions(): Flow<List<CompletionEntity>>
    @Query("SELECT * FROM completions") suspend fun completionsNow(): List<CompletionEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setCompletion(c: CompletionEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setCompletions(c: List<CompletionEntity>)
    @Query("SELECT COUNT(*) FROM completions WHERE taskId = :id AND date = :d AND done = 1")
    suspend fun doneCount(id: Long, d: String): Int

    @Query("SELECT * FROM notes ORDER BY createdAt DESC") fun notes(): Flow<List<NoteEntity>>
    @Query("SELECT * FROM notes") suspend fun notesNow(): List<NoteEntity>
    @Insert suspend fun insertNote(n: NoteEntity)
    @Query("DELETE FROM notes WHERE id = :id") suspend fun deleteNote(id: Long)

    @Query("SELECT * FROM focus") fun focus(): Flow<List<FocusEntity>>
    @Query("SELECT * FROM focus") suspend fun focusNow(): List<FocusEntity>
    @Insert suspend fun insertFocus(f: FocusEntity)
}

@Database(
    entities = [TaskEntity::class, CompletionEntity::class, NoteEntity::class, FocusEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): PlannerDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "adplanner.db")
                .build().also { inst = it }
        }
    }
}
