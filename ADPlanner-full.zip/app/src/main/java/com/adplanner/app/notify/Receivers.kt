package com.adplanner.app.notify

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.adplanner.app.data.AppDb
import com.adplanner.app.data.CompletionEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

private fun BroadcastReceiver.async(block: suspend () -> Unit) {
    val pr = goAsync()
    CoroutineScope(Dispatchers.IO).launch {
        try { block() } finally { pr.finish() }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("taskId", -1)
        val snoozed = intent.getBooleanExtra("snoozed", false)
        async {
            val dao = AppDb.get(ctx).dao()
            val t = dao.task(id) ?: return@async
            val alreadyDone = dao.doneCount(id, LocalDate.now().toString()) > 0
            if (!(snoozed && alreadyDone)) Reminders.show(ctx, t)
            if (!snoozed) Reminders.schedule(ctx, t) // arm the next occurrence
        }
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("taskId", -1)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.cancel(id.toInt())
        when (intent.action) {
            Reminders.ACT_DONE -> async {
                AppDb.get(ctx).dao().setCompletion(CompletionEntity(id, LocalDate.now().toString(), true))
            }
            Reminders.ACT_SNOOZE -> Reminders.snooze(ctx, id, 10)
        }
    }
}

class FocusReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        async { FocusStore.finish(ctx, notify = true) }
    }
}

/** Boot, clock change, timezone change, app update: re-arm every alarm. */
class SystemReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        async { Reminders.rescheduleAll(ctx) }
    }
}
