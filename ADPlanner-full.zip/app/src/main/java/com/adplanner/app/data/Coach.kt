package com.adplanner.app.data

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Coach {
    /** POST {"prompt": "..."} to the free Cloudflare Worker, expects {"reply": "..."}. */
    suspend fun ask(url: String, prompt: String): String = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type", "application/json")
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.doOutput = true
        c.outputStream.use { it.write(JSONObject().put("prompt", prompt).toString().toByteArray()) }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) error("server returned $code")
        JSONObject(body).optString("reply", "(empty reply)")
    }

    /** Minimal formatter: **bold** and strips leading markdown bullets/headers. */
    fun format(s: String): AnnotatedString = buildAnnotatedString {
        val clean = s.lines().joinToString("\n") { it.trimStart('#', ' ').replace(Regex("^[*-]\\s+"), "• ") }
        val parts = clean.split("**")
        parts.forEachIndexed { i, p ->
            if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(p) } else append(p)
        }
    }
}
