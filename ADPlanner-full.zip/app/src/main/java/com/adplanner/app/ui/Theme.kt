package com.adplanner.app.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

data class ThemeDef(
    val name: String, val primary: Color, val secondary: Color,
    val darkBg: Color, val darkSurface: Color, val lightBg: Color
)

// Colours are approximations of the web tracker's themes; tweak freely.
val Themes = listOf(
    ThemeDef("Burgundy Sage", Color(0xFF7B1E3A), Color(0xFF8FA58B), Color(0xFF1A0E12), Color(0xFF2A1820), Color(0xFFFAF3F0)),
    ThemeDef("Mocha Lavender", Color(0xFF6F4E37), Color(0xFFB8A9D9), Color(0xFF17110E), Color(0xFF261C17), Color(0xFFF7F2EE)),
    ThemeDef("Aubergine Gold", Color(0xFF4B1D5C), Color(0xFFD4A82F), Color(0xFF140A18), Color(0xFF221229), Color(0xFFF8F3FA)),
    ThemeDef("Cobalt Lime", Color(0xFF1F4FD8), Color(0xFFA3E635), Color(0xFF0A0F1E), Color(0xFF141B33), Color(0xFFF2F5FF)),
    ThemeDef("Neon Rose", Color(0xFFFF2E7E), Color(0xFF38BDF8), Color(0xFF000000), Color(0xFF14090F), Color(0xFFFFF5F8)),
    ThemeDef("Black", Color(0xFF111111), Color(0xFF9CA3AF), Color(0xFF000000), Color(0xFF151515), Color(0xFFF5F5F5)),
    ThemeDef("Cerulean", Color(0xFF007BA7), Color(0xFFFFB4A2), Color(0xFF06141A), Color(0xFF0E2630), Color(0xFFF0F8FB)),
    ThemeDef("Slate", Color(0xFF475569), Color(0xFF5EEAD4), Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFFF1F5F9))
)

fun scheme(t: ThemeDef, dark: Boolean): ColorScheme =
    if (dark) darkColorScheme(
        primary = lerp(t.primary, Color.White, 0.4f), onPrimary = Color.Black,
        secondary = t.secondary, onSecondary = Color.Black,
        background = t.darkBg, onBackground = Color(0xFFEDEDED),
        surface = t.darkSurface, onSurface = Color(0xFFEDEDED),
        surfaceVariant = t.darkSurface, onSurfaceVariant = Color(0xFFC8C8C8),
        primaryContainer = t.primary, onPrimaryContainer = Color.White,
        secondaryContainer = lerp(t.secondary, t.darkBg, 0.7f), onSecondaryContainer = Color.White
    ) else lightColorScheme(
        primary = t.primary, onPrimary = Color.White,
        secondary = t.secondary, onSecondary = Color.Black,
        background = t.lightBg, onBackground = Color(0xFF1B1B1B),
        surface = Color.White, onSurface = Color(0xFF1B1B1B),
        surfaceVariant = lerp(t.lightBg, t.primary, 0.08f), onSurfaceVariant = Color(0xFF444444),
        primaryContainer = lerp(Color.White, t.primary, 0.15f), onPrimaryContainer = Color(0xFF1B1B1B),
        secondaryContainer = lerp(Color.White, t.secondary, 0.3f), onSecondaryContainer = Color(0xFF1B1B1B)
    )
