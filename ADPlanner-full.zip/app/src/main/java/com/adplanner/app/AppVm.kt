package com.adplanner.app

import android.app.Application
import android.app.NotificationManager
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adplanner.app.data.*
import com.adplanner.app.notify.FocusStore
import com.adplanner.app.notify.Reminders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

class AppVm(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val prefs = Prefs(app)

    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val comps = dao.completions().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val notes = dao.notes().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val focus = dao.focus().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var theme by mutableStateOf(prefs.theme); private set
    var mode by mutableStateOf(prefs.mode); private set
    var coachUrl by mutableStateOf(prefs.coachUrl); private set
    var onboarded by mutableStateOf(prefs.onboarded); private set
    var selectedDate by mutableStateOf(LocalDate.now())
    var coachText by mutableStateOf(""); private set
    var coachBusy by mutableStateOf(false); private set
    var status by mutableStateOf("")
    var focusEnd by mutableLongStateOf(prefs.focusEnd); private set
    var focusMin by mutableIntStateOf(prefs.focusMin); private set

    init {
        viewModelScope.launch(Dispatchers.IO) {
            if (dao.tasksNow().isEmpty()) Logic.seed().forEach { dao.insertTask(it) }
            Reminders.rescheduleAll(app)
        }
    }

    fun setTheme(v: String) { theme = v; prefs.theme = v }
    fun setMode(v: String) { mode = v; prefs.mode = v }
    fun setCoachUrl(v: String) { coachUrl = v.trim(); prefs.coachUrl = v.trim() }
    fun finishOnboarding() { onboarded = true; prefs.onboarded = true }

    fun setDone(t: TaskEntity, date: LocalDate, done: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        dao.setCompletion(CompletionEntity(t.id, date.toString(), done))
        if (done && date == LocalDate.now()) app.getSystemService(NotificationManager::class.java).cancel(t.id.toInt())
    }

    fun saveTask(t: TaskEntity) = viewModelScope.launch(Dispatchers.IO) {
        val id = if (t.id == 0L) dao.insertTask(t) else { dao.updateTask(t); t.id }
        Reminders.schedule(app, t.copy(id = id))
    }

    fun deleteTask(t: TaskEntity) = viewModelScope.launch(Dispatchers.IO) {
        Reminders.cancel(app, t.id)
        dao.deleteCompletionsFor(t.id)
        dao.deleteTask(t.id)
    }

    fun addNote(text: String) = viewModelScope.launch(Dispatchers.IO) {
        if (text.isNotBlank()) dao.insertNote(NoteEntity(text = text.trim(), createdAt = System.currentTimeMillis()))
    }
    fun deleteNote(n: NoteEntity) = viewModelScope.launch(Dispatchers.IO) { dao.deleteNote(n.id) }

    // ---- Focus timer: end time is stored, so it stays correct with the screen off ----
    fun startFocus(min: Int) {
        val end = System.currentTimeMillis() + min * 60_000L
        prefs.focusMin = min; prefs.focusEnd = end
        focusMin = min; focusEnd = end
        Reminders.scheduleFocus(app, end)
    }
    fun stopFocus() {
        Reminders.cancelFocus(app); prefs.clearFocus(); focusEnd = 0L
    }
    fun syncFocus() {
        val e = prefs.focusEnd
        if (e != 0L && System.currentTimeMillis() >= e + 5000) {
            viewModelScope.launch(Dispatchers.IO) { FocusStore.finish(app, notify = false) }
        }
        focusEnd = prefs.focusEnd
    }

    // ---- Daily Coach ----
    fun askCoach(now: LocalDateTime) {
        if (coachBusy) return
        if (coachUrl.isBlank()) { coachText = "Add your Coach server URL in Settings first."; return }
        coachBusy = true
        val done = Logic.doneSet(comps.value)
        val st = Logic.day(tasks.value, done, now.toLocalDate(), now)
        val nowMin = now.hour * 60 + now.minute
        val left = tasks.value.filter {
            Logic.applies(it, now.toLocalDate()) && "${it.id}|${now.toLocalDate()}" !in done && it.endMin > nowMin
        }.joinToString { "${it.title} (${fmtMin(it.startMin)})" }
        val streak = Logic.streak(tasks.value, done, now)
        val prompt = "You are a short, practical daily coach for a student building Python and AI skills. " +
            "Time now: ${fmtMin(nowMin)}. Done today: ${st.done} of ${st.scheduled}. Day streak: $streak. " +
            "Still to do: ${left.ifBlank { "nothing" }}. Give a motivating tip and the single next action in under 70 words, plain text."
        viewModelScope.launch {
            coachText = try { Coach.ask(coachUrl, prompt) } catch (e: Exception) { "Coach unavailable: ${e.message}" }
            coachBusy = false
        }
    }

    // ---- Backup ----
    fun exportTo(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        status = try {
            val text = Backup.export(app)
            app.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
            "Backup saved."
        } catch (e: Exception) { "Export failed: ${e.message}" }
    }

    fun importFrom(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        status = try {
            val text = app.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: error("empty file")
            val msg = Backup.import(app, text)
            Reminders.rescheduleAll(app)
            msg
        } catch (e: Exception) { "Import failed: ${e.message}" }
    }
}
