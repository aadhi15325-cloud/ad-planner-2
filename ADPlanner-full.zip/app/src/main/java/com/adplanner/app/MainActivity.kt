package com.adplanner.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.adplanner.app.notify.Reminders
import com.adplanner.app.ui.Onboarding
import com.adplanner.app.ui.Root
import com.adplanner.app.ui.Themes
import com.adplanner.app.ui.scheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminders.ensureChannels(this)
        setContent {
            val vm: AppVm = viewModel()
            val sys = isSystemInDarkTheme()
            val dark = when (vm.mode) { "dark" -> true; "light" -> false; else -> sys }
            val def = Themes.firstOrNull { it.name == vm.theme } ?: Themes[0]
            MaterialTheme(colorScheme = scheme(def, dark)) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (!vm.onboarded) Onboarding(vm) else Root(vm)
                }
            }
        }
    }
}
