package com.adplanner.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adplanner.app.AppVm
import com.adplanner.app.data.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private val dayFmt = DateTimeFormatter.ofPattern("EEE, d MMM")
private val DAY_LETTERS = listOf("M", "T", "W", "T", "F", "S", "S")

@Composable
fun rememberNow(periodMs: Long = 20_000): State<LocalDateTime> =
    produceState(LocalDateTime.now()) { while (true) { delay(periodMs); value = LocalDateTime.now() } }

@Composable
fun Reactor(size: Int = 56) {
    val c = MaterialTheme.colorScheme.primary
    val s = MaterialTheme.colorScheme.secondary
    Canvas(Modifier.size(size.dp)) {
        val r = this.size.minDimension / 2
        drawCircle(c, r * 0.95f, style = Stroke(width = r * 0.1f))
        drawCircle(s, r * 0.65f, style = Stroke(width = r * 0.06f))
        drawCircle(c, r * 0.3f)
    }
}

// ------------------------------------------------------------------ Onboarding
@Composable
fun Onboarding(vm: AppVm) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.finishOnboarding() }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Reactor(120)
        Spacer(Modifier.height(24.dp))
        Text("AD Planner", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Your daily timetable with reminders that ring even when the app is closed.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.finishOnboarding()
        }) { Text("Allow notifications & start") }
        TextButton(onClick = { vm.finishOnboarding() }) { Text("Skip for now") }
    }
}

// ------------------------------------------------------------------ Root
@Composable
fun Root(vm: AppVm) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var overlay by rememberSaveable { mutableStateOf("") }
    BackHandler(overlay.isNotEmpty()) { overlay = "" }
    when (overlay) {
        "focus" -> FocusScreen(vm) { overlay = "" }
        "timetable" -> TimetableScreen(vm) { overlay = "" }
        else -> {
            val items = listOf(
                "Today" to Icons.Filled.Today, "Week" to Icons.Filled.DateRange,
                "Stats" to Icons.Filled.BarChart, "Notes" to Icons.Filled.Description,
                "Settings" to Icons.Filled.Settings
            )
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        items.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Icon(icon, contentDescription = label) }, label = { Text(label) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).statusBarsPadding()) {
                    when (tab) {
                        0 -> TodayScreen(vm) { overlay = "focus" }
                        1 -> WeekScreen(vm, onOpenDay = { tab = 0 }, onEdit = { overlay = "timetable" })
                        2 -> StatsScreen(vm)
                        3 -> NotesScreen(vm)
                        else -> SettingsScreen(vm) { overlay = "timetable" }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Today
@Composable
fun TodayScreen(vm: AppVm, openFocus: () -> Unit) {
    val now by rememberNow()
    val tasks by vm.tasks.collectAsState()
    val comps by vm.comps.collectAsState()
    val done = remember(comps) { Logic.doneSet(comps) }
    val date = vm.selectedDate
    val today = now.toLocalDate()
    val nowMin = now.hour * 60 + now.minute
    val list = tasks.filter { Logic.applies(it, date) }
    val st = Logic.day(tasks, done, date, now)
    val streak = Logic.streak(tasks, done, now)

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Reactor(40)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AD Planner", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("🔥 $streak day streak", fontSize = 13.sp)
                }
                IconButton(onClick = openFocus) { Icon(Icons.Filled.Timer, "Focus") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.selectedDate = date.minusDays(1) }) { Icon(Icons.Filled.KeyboardArrowLeft, "Previous day") }
                Text(
                    (if (date == today) "Today · " else "") + date.format(dayFmt),
                    Modifier.weight(1f).clickable { vm.selectedDate = today },
                    textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                )
                IconButton(onClick = { vm.selectedDate = date.plusDays(1) }) { Icon(Icons.Filled.KeyboardArrowRight, "Next day") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("${st.done} of ${st.scheduled} done", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { if (st.scheduled == 0) 0f else st.done.toFloat() / st.scheduled },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        item { CoachCard(vm, now) }
        items(list, key = { it.id }) { t ->
            val isDone = "${t.id}|$date" in done
            val current = date == today && nowMin >= t.startMin && nowMin < t.endMin
            val missed = !isDone && (date.isBefore(today) || (date == today && t.endMin <= nowMin))
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (current) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isDone, enabled = !date.isAfter(today),
                        onCheckedChange = { vm.setDone(t, date, it) }
                    )
                    Column(Modifier.weight(1f)) {
                        Text(t.title, fontWeight = FontWeight.SemiBold)
                        Text("${fmtMin(t.startMin)} – ${fmtMin(t.endMin)} · ${t.category}", fontSize = 12.sp)
                    }
                    if (missed) Text("Missed", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    if (current) Text("Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
fun CoachCard(vm: AppVm, now: LocalDateTime) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Daily Coach", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (vm.coachBusy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                else TextButton(onClick = { vm.askCoach(now) }) { Text(if (vm.coachText.isBlank()) "Ask" else "Refresh") }
            }
            if (vm.coachText.isNotBlank()) Text(com.adplanner.app.data.Coach.format(vm.coachText))
        }
    }
}

// ------------------------------------------------------------------ Week
@Composable
fun WeekScreen(vm: AppVm, onOpenDay: () -> Unit, onEdit: () -> Unit) {
    val now by rememberNow(60_000)
    val tasks by vm.tasks.collectAsState()
    val comps by vm.comps.collectAsState()
    val done = remember(comps) { Logic.doneSet(comps) }
    val today = now.toLocalDate()
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("This week", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = onEdit) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp)); Text("Timetable") }
        }
        for (i in 0..6) {
            val d = monday.plusDays(i.toLong())
            val st = Logic.day(tasks, done, d, now)
            Card(
                Modifier.fillMaxWidth().clickable { vm.selectedDate = d; onOpenDay() },
                colors = CardDefaults.cardColors(
                    containerColor = if (d == today) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(Modifier.padding(12.dp)) {
                    Row {
                        Text(d.format(dayFmt), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text(if (d.isAfter(today)) "${st.scheduled} planned" else "${st.done}/${st.counted}")
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { if (st.scheduled == 0) 0f else st.done.toFloat() / st.scheduled },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Stats
@Composable
fun StatsScreen(vm: AppVm) {
    val now by rememberNow(60_000)
    val tasks by vm.tasks.collectAsState()
    val comps by vm.comps.collectAsState()
    val focus by vm.focus.collectAsState()
    val done = remember(comps) { Logic.doneSet(comps) }
    val today = now.toLocalDate()
    val streak = Logic.streak(tasks, done, now)
    val bars = (6 downTo 0).map { Logic.day(tasks, done, today.minusDays(it.toLong()), now) }
    val labels = (6 downTo 0).map { today.minusDays(it.toLong()).dayOfWeek.name.take(1) }
    val focusToday = focus.filter { it.date == today.toString() }.sumOf { it.minutes }
    val focusWeek = focus.filter { !LocalDate.parse(it.date).isBefore(today.minusDays(6)) }.sumOf { it.minutes }
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Stats", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Streak", "$streak days", Modifier.weight(1f))
            StatCard("Focus today", "$focusToday min", Modifier.weight(1f))
            StatCard("Focus 7d", "$focusWeek min", Modifier.weight(1f))
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Last 7 days", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                    val w = size.width / 7
                    bars.forEachIndexed { i, b ->
                        val x = i * w + w * 0.2f
                        drawRect(track, Offset(x, 0f), Size(w * 0.6f, size.height))
                        val h = size.height * (if (b.counted == 0) 0f else b.ratio)
                        drawRect(primary, Offset(x, size.height - h), Size(w * 0.6f, h))
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    labels.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp) }
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("By category (30 days)", fontWeight = FontWeight.Bold)
                Categories.forEach { cat ->
                    val r = Logic.catRate(tasks, done, now, cat)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(cat, Modifier.width(80.dp))
                        LinearProgressIndicator(progress = { r ?: 0f }, modifier = Modifier.weight(1f))
                        Text(if (r == null) "  –" else "  ${(r * 100).toInt()}%", Modifier.width(52.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

// ------------------------------------------------------------------ Notes
@Composable
fun NotesScreen(vm: AppVm) {
    val notes by vm.notes.collectAsState()
    var text by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Notes", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Write a note…") })
            IconButton(onClick = { vm.addNote(text); text = "" }) { Icon(Icons.Filled.Add, "Add") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(notes, key = { it.id }) { n ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(n.text)
                            Text(
                                java.time.Instant.ofEpochMilli(n.createdAt).atZone(java.time.ZoneId.systemDefault())
                                    .format(DateTimeFormatter.ofPattern("d MMM, h:mm a")), fontSize = 11.sp
                            )
                        }
                        IconButton(onClick = { vm.deleteNote(n) }) { Icon(Icons.Filled.Delete, "Delete") }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Focus
@Composable
fun FocusScreen(vm: AppVm, onBack: () -> Unit) {
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { tick = System.currentTimeMillis(); vm.syncFocus(); delay(1000) } }
    val running = vm.focusEnd > 0
    val remaining = ((vm.focusEnd - tick) / 1000).coerceAtLeast(0)
    var pick by rememberSaveable { mutableIntStateOf(25) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
            Text("Focus", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(48.dp))
        val shown = if (running) remaining else pick * 60L
        Text("%02d:%02d".format(shown / 60, shown % 60), fontSize = 72.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        if (!running) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 25, 45, 60).forEach { m ->
                    FilterChip(selected = pick == m, onClick = { pick = m }, label = { Text("$m min") })
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { vm.startFocus(pick) }) { Text("Start") }
        } else {
            Text("Session ends with an alarm, even if the screen is off.", fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = { vm.stopFocus() }) { Text("Stop") }
        }
    }
}

// ------------------------------------------------------------------ Timetable editor
@Composable
fun TimetableScreen(vm: AppVm, onBack: () -> Unit) {
    val tasks by vm.tasks.collectAsState()
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = { FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, "Add task") } }
    ) { pad ->
        Column(Modifier.padding(pad).statusBarsPadding().padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                Text("Timetable", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(tasks, key = { it.id }) { t ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.title, fontWeight = FontWeight.SemiBold)
                                Text("${fmtMin(t.startMin)} – ${fmtMin(t.endMin)} · ${t.category}" + if (t.remind) " · 🔔" else "", fontSize = 12.sp)
                                Text(DAY_LETTERS.indices.joinToString(" ") { i -> if ((t.daysMask shr i) and 1 == 1) DAY_LETTERS[i] else "·" }, fontSize = 11.sp)
                            }
                            IconButton(onClick = { editing = t }) { Icon(Icons.Filled.Edit, "Edit") }
                            IconButton(onClick = { vm.deleteTask(t) }) { Icon(Icons.Filled.Delete, "Delete") }
                        }
                    }
                }
            }
        }
    }
    if (adding) TaskDialog(null, onDismiss = { adding = false }) { vm.saveTask(it); adding = false }
    editing?.let { e -> TaskDialog(e, onDismiss = { editing = null }) { vm.saveTask(it); editing = null } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskDialog(initial: TaskEntity?, onDismiss: () -> Unit, onSave: (TaskEntity) -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var start by remember { mutableIntStateOf(initial?.startMin ?: 480) }
    var end by remember { mutableIntStateOf(initial?.endMin ?: 540) }
    var cat by remember { mutableStateOf(initial?.category ?: Categories[0]) }
    var mask by remember { mutableIntStateOf(initial?.daysMask ?: 127) }
    var remind by remember { mutableStateOf(initial?.remind ?: true) }
    var error by remember { mutableStateOf("") }
    fun pick(cur: Int, set: (Int) -> Unit) =
        TimePickerDialog(ctx, { _, h, m -> set(h * 60 + m) }, cur / 60, cur % 60, false).show()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add task" else "Edit task") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pick(start) { start = it } }) { Text("Start ${fmtMin(start)}") }
                    OutlinedButton(onClick = { pick(end) { end = it } }) { Text("End ${fmtMin(end)}") }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Categories.forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DAY_LETTERS.forEachIndexed { i, l ->
                        FilterChip(
                            selected = (mask shr i) and 1 == 1,
                            onClick = { mask = mask xor (1 shl i) }, label = { Text(l) }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reminder", Modifier.weight(1f))
                    Switch(remind, { remind = it })
                }
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    title.isBlank() -> error = "Enter a title."
                    end <= start -> error = "End must be after start."
                    mask == 0 -> error = "Pick at least one day."
                    else -> onSave(
                        (initial ?: TaskEntity(title = "", startMin = 0, endMin = 0, category = cat))
                            .copy(title = title.trim(), startMin = start, endMin = end, category = cat, daysMask = mask, remind = remind)
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ------------------------------------------------------------------ Settings
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: AppVm, openTimetable: () -> Unit) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf(vm.coachUrl) }
    var confirmImport by remember { mutableStateOf<Uri?>(null) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::exportTo) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { confirmImport = it }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Text("Theme", fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Themes.forEach { t ->
                FilterChip(
                    selected = vm.theme == t.name, onClick = { vm.setTheme(t.name) },
                    label = { Text(t.name) },
                    leadingIcon = { Box(Modifier.size(14.dp).background(t.primary, CircleShape)) }
                )
            }
        }
        Text("Mode", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (k, l) ->
                FilterChip(selected = vm.mode == k, onClick = { vm.setMode(k) }, label = { Text(l) })
            }
        }

        HorizontalDivider()
        Text("Reminders", fontWeight = FontWeight.SemiBold)
        if (Build.VERSION.SDK_INT >= 33) {
            OutlinedButton(onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow notifications") }
        }
        if (Build.VERSION.SDK_INT in 31..32) {
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Allow exact alarms") }
        }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }) { Text("Battery optimisation settings") }
        Text(
            "Poco/Xiaomi: also enable Autostart for AD Planner and set Battery saver to \"No restrictions\", or reminders may be delayed.",
            fontSize = 12.sp
        )
        OutlinedButton(onClick = openTimetable) { Text("Edit timetable") }

        HorizontalDivider()
        Text("Daily Coach server URL", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            url, { url = it; vm.setCoachUrl(it) }, Modifier.fillMaxWidth(),
            placeholder = { Text("https://your-worker.workers.dev") }, singleLine = true
        )

        HorizontalDivider()
        Text("Backup & import", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exportLauncher.launch("adplanner-backup.json") }) { Text("Export") }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("Import") }
        }
        if (vm.status.isNotBlank()) Text(vm.status, fontSize = 13.sp)
        Text("Import replaces your timetable and history. Works with this app's backup and the old web tracker's export.", fontSize = 12.sp)
    }

    confirmImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmImport = null },
            title = { Text("Replace timetable?") },
            text = { Text("Importing will replace your current timetable and completion history.") },
            confirmButton = { TextButton(onClick = { vm.importFrom(uri); confirmImport = null }) { Text("Import") } },
            dismissButton = { TextButton(onClick = { confirmImport = null }) { Text("Cancel") } }
        )
    }
}
