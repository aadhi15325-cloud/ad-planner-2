package com.adplanner.app.data

import android.content.Context

class Prefs(c: Context) {
    private val sp = c.applicationContext.getSharedPreferences("adp", Context.MODE_PRIVATE)
    var theme: String
        get() = sp.getString("theme", "Burgundy Sage") ?: "Burgundy Sage"
        set(v) = sp.edit().putString("theme", v).apply()
    var mode: String // system | light | dark
        get() = sp.getString("mode", "system") ?: "system"
        set(v) = sp.edit().putString("mode", v).apply()
    var coachUrl: String
        get() = sp.getString("coachUrl", "") ?: ""
        set(v) = sp.edit().putString("coachUrl", v).apply()
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) = sp.edit().putBoolean("onboarded", v).apply()
    var focusEnd: Long
        get() = sp.getLong("focusEnd", 0L)
        set(v) = sp.edit().putLong("focusEnd", v).apply()
    var focusMin: Int
        get() = sp.getInt("focusMin", 25)
        set(v) = sp.edit().putInt("focusMin", v).apply()
    fun clearFocus() = sp.edit().remove("focusEnd").apply()
}
