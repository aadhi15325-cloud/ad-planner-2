package com.adplanner.app.notify

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import com.adplanner.app.MainActivity
import com.adplanner.app.R
import com.adplanner.app.data.*
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

object Reminders {
    const val CH = "reminders"
    const val CH_FOCUS = "focus"
    const val ACT_FIRE = "com.adplanner.app.FIRE"
    const val ACT_DONE = "com.adplanner.app.DONE"
    const val ACT_SNOOZE = "com.adplanner.app.SNOOZE"
    const val ACT_FOCUS = "com.adplanner.app.FOCUS_END"
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Task reminders", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_FOCUS, "Focus timer", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) }
        )
    }

    fun nextTrigger(t: TaskEntity, now: LocalDateTime): LocalDateTime? {
        for (o in 0..7) {
            val d = now.toLocalDate().plusDays(o.toLong())
            if (!Logic.applies(t, d)) continue
            val dt = d.atTime(t.startMin / 60, t.startMin % 60)
            if (dt.isAfter(now)) return dt
        }
        return null
    }

    private fun fireIntent(c: Context, id: Long, snoozed: Boolean) =
        Intent(c, ReminderReceiver::class.java).setAction(ACT_FIRE)
            .setData(Uri.parse("adp://fire/$id/$snoozed"))
            .putExtra("taskId", id).putExtra("snoozed", snoozed)

    private fun setAt(am: AlarmManager, ms: Long, p: PendingIntent) {
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p)
        }
    }

    fun schedule(c: Context, t: TaskEntity) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = PendingIntent.getBroadcast(c, t.id.toInt(), fireIntent(c, t.id, false), FLAGS)
        am.cancel(p)
        if (!t.remind) return
        val n = nextTrigger(t, LocalDateTime.now()) ?: return
        setAt(am, n.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), p)
    }

    fun cancel(c: Context, id: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(PendingIntent.getBroadcast(c, id.toInt(), fireIntent(c, id, false), FLAGS))
        am.cancel(PendingIntent.getBroadcast(c, 1_000_000 + id.toInt(), fireIntent(c, id, true), FLAGS))
    }

    suspend fun rescheduleAll(c: Context) {
        ensureChannels(c)
        AppDb.get(c).dao().tasksNow().forEach { schedule(c, it) }
        val end = Prefs(c).focusEnd
        if (end > System.currentTimeMillis()) scheduleFocus(c, end)
    }

    fun snooze(c: Context, id: Long, minutes: Int) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = PendingIntent.getBroadcast(c, 1_000_000 + id.toInt(), fireIntent(c, id, true), FLAGS)
        setAt(am, System.currentTimeMillis() + minutes * 60_000L, p)
    }

    fun show(c: Context, t: TaskEntity) {
        ensureChannels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), FLAGS)
        fun act(action: String, base: Int): PendingIntent = PendingIntent.getBroadcast(
            c, base + t.id.toInt(),
            Intent(c, ActionReceiver::class.java).setAction(action)
                .setData(Uri.parse("adp://${action.substringAfterLast('.')}/${t.id}"))
                .putExtra("taskId", t.id), FLAGS
        )
        val icon = Icon.createWithResource(c, R.drawable.ic_notif)
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(t.title)
            .setContentText("${fmtMin(t.startMin)} – ${fmtMin(t.endMin)} · ${t.category}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_REMINDER)
            .addAction(Notification.Action.Builder(icon, "Done", act(ACT_DONE, 2_000_000)).build())
            .addAction(Notification.Action.Builder(icon, "Snooze 10m", act(ACT_SNOOZE, 3_000_000)).build())
            .build()
        nm.notify(t.id.toInt(), n)
    }

    fun scheduleFocus(c: Context, endMs: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        setAt(am, endMs, focusPi(c))
    }

    fun cancelFocus(c: Context) {
        c.getSystemService(AlarmManager::class.java).cancel(focusPi(c))
    }

    private fun focusPi(c: Context) = PendingIntent.getBroadcast(
        c, 9_999_999,
        Intent(c, FocusReceiver::class.java).setAction(ACT_FOCUS).setData(Uri.parse("adp://focus")), FLAGS
    )

    fun showFocusDone(c: Context, minutes: Int) {
        ensureChannels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), FLAGS)
        nm.notify(
            9_999_999,
            Notification.Builder(c, CH_FOCUS).setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Focus session complete")
                .setContentText("$minutes minutes done. Take a short break.")
                .setContentIntent(open).setAutoCancel(true).build()
        )
    }
}

object FocusStore {
    suspend fun finish(c: Context, notify: Boolean) {
        val p = Prefs(c)
        val end = p.focusEnd
        val min = p.focusMin
        if (end == 0L) return
        p.clearFocus()
        AppDb.get(c).dao().insertFocus(FocusEntity(date = LocalDate.now().toString(), minutes = min))
        if (notify) Reminders.showFocusDone(c, min)
    }
}
