// Cloudflare Worker (free plan). Add secret GEMINI_KEY, deploy, then paste the
// worker URL into AD Planner > Settings > Coach server URL.
export default {
  async fetch(req, env) {
    const h = { "Content-Type": "application/json" };
    if (req.method !== "POST") return new Response(JSON.stringify({ reply: "POST only" }), { status: 405, headers: h });
    let prompt = "";
    try { prompt = String((await req.json()).prompt || "").slice(0, 4000); } catch (e) {}
    if (!prompt) return new Response(JSON.stringify({ reply: "Empty prompt" }), { status: 400, headers: h });
    const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + env.GEMINI_KEY;
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
    });
    const j = await r.json();
    const reply = j?.candidates?.[0]?.content?.parts?.[0]?.text ?? "Coach is unavailable right now.";
    return new Response(JSON.stringify({ reply }), { headers: h });
  },
};
