# AD Planner 2.0 (native Android)

Kotlin + Jetpack Compose + Room. 5 tabs (Today, Week, Stats, Notes, Settings), 8 themes,
timetable editor, reminders with Done / Snooze (alarms survive reboot and clock changes),
Focus timer, Daily Coach, JSON backup/import.

## Build the APK on GitHub (no Android Studio)
1. Create a GitHub repo and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Repo > Actions > "Build APK" > Run workflow.
3. When it finishes, open the run > Artifacts > `ADPlanner-debug-apk`, unzip, install `app-debug.apk` on the phone.
4. If the build fails, open the failed step and send me the red error lines.

## Daily Coach (free)
1. Get a free Gemini API key (aistudio.google.com).
2. Cloudflare dashboard > Workers > Create > paste `server/worker.js` > add secret `GEMINI_KEY`.
3. Paste the worker URL in the app: Settings > Daily Coach server URL.

## Notes
- Not compiled or tested yet: first build may need small fixes.
- Seed timetable is a placeholder; replace via Settings > Import (old tracker export) or Timetable editor.
- Not included: Firebase cloud sync, signed release APK.
